/* Fragmento de configuración de phpMyAdmin */

/* Pegue esto en su archivo config.inc.php */

$cfg['Console']['Mode'] = 'collapse';
$cfg['lang'] = 'es';
